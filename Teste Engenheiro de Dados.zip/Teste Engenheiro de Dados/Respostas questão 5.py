# Databricks notebook source
# MAGIC %sql
# MAGIC -- Qual país possui a maior quantidade de itens cancelados?
# MAGIC select 
# MAGIC   c.country, 
# MAGIC   sum(od.quantity_ordered) quantity_ordered 
# MAGIC from orders_update o
# MAGIC inner join orderdetails_update od
# MAGIC   on o.order_number = od.order_number 
# MAGIC inner join customers_update c 
# MAGIC   on o.customer_number = c.customer_number
# MAGIC where o.status = 'Cancelled'
# MAGIC group by c.country 
# MAGIC order by sum(od.quantity_ordered) desc
# MAGIC limit 1

# COMMAND ----------

# MAGIC %sql
# MAGIC --Qual o faturamento da linha de produto mais vendido, considere como os itens Shipped, cujo o pedido foi realizado no ano de 2005
# MAGIC select 
# MAGIC   p.product_name,
# MAGIC   sum(od.quantity_ordered) quantity_ordered, 
# MAGIC   sum(od.price_each) price_each, 
# MAGIC   sum(od.quantity_ordered) * sum(od.price_each) total_price
# MAGIC from products p 
# MAGIC inner join orderdetails od
# MAGIC   on p.product_code  = od.product_code 
# MAGIC inner join orders o	
# MAGIC   on od.order_number = o.order_number 
# MAGIC where o.status = 'Shipped'
# MAGIC   and date_part('year', o.order_date) = 2005 
# MAGIC group by p.product_name
# MAGIC order by sum(od.quantity_ordered) desc
# MAGIC limit 1

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Nome, sobrenome e e-mail dos vendedores do Japão, o local-part do e-mail
# MAGIC deve estar mascarado
# MAGIC select distinct 
# MAGIC   e.first_name, 
# MAGIC   e.last_name,
# MAGIC   ('XXXXX'|| substr(e.email, position('@',e.email),char_length(e.email))) email
# MAGIC from employees e 
# MAGIC inner join customers c 
# MAGIC on e.employee_number = c.sales_rep_employee_number 
# MAGIC where c.country = 'Japan'