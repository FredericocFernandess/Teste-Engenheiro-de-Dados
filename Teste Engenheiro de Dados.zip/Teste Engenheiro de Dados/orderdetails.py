# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "orderdetails" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)

# COMMAND ----------

target_table_name = "orderdetails"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table orderdetails_update;
# MAGIC create table orderdetails_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   order_number, 
# MAGIC   product_code, 
# MAGIC   quantity_ordered, 
# MAGIC   price_each, 
# MAGIC   order_line_number,	
# MAGIC   'U' flag
# MAGIC from orderdetails

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO orderdetails_update
# MAGIC USING orderdetails
# MAGIC ON orderdetails_update.order_number = orderdetails.order_number AND orderdetails_update.product_code = orderdetails.product_code
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     order_number = orderdetails.order_number, 	
# MAGIC     product_code = orderdetails.product_code, 
# MAGIC     quantity_ordered = orderdetails.quantity_ordered, 
# MAGIC     price_each = orderdetails.price_each, 
# MAGIC     order_line_number = orderdetails.order_line_number,
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     order_number, 
# MAGIC     product_code, 
# MAGIC     quantity_ordered, 
# MAGIC     price_each, 
# MAGIC     order_line_number,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     orderdetails.order_number, 
# MAGIC     orderdetails.product_code, 
# MAGIC     orderdetails.quantity_ordered, 
# MAGIC     orderdetails.price_each, 
# MAGIC     orderdetails.order_line_number,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'