# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "products" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)

# COMMAND ----------

target_table_name = "products"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table products_update;
# MAGIC create table products_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   product_code, 
# MAGIC   product_name, 
# MAGIC   product_line, 
# MAGIC   product_scale, 
# MAGIC   product_vendor, 
# MAGIC   product_description, 
# MAGIC   quantity_in_stock, 
# MAGIC   buy_price, 
# MAGIC   msrp,		
# MAGIC   'U' flag
# MAGIC from products

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO products_update
# MAGIC USING products
# MAGIC ON products_update.product_code = products.product_code
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     product_code = products.product_code, 
# MAGIC     product_name = products.product_name, 
# MAGIC     product_line = products.product_line, 
# MAGIC     product_scale = products.product_scale, 
# MAGIC     product_vendor = products.product_vendor, 
# MAGIC     product_description = products.product_description, 
# MAGIC     quantity_in_stock = products.quantity_in_stock, 
# MAGIC     buy_price = products.buy_price, 
# MAGIC     msrp = products.msrp,	
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     product_code, 
# MAGIC     product_name, 
# MAGIC     product_line, 
# MAGIC     product_scale, 
# MAGIC     product_vendor, 
# MAGIC     product_description, 
# MAGIC     quantity_in_stock, 
# MAGIC     buy_price, 
# MAGIC     msrp,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     products.product_code, 
# MAGIC     products.product_name, 
# MAGIC     products.product_line, 
# MAGIC     products.product_scale, 
# MAGIC     products.product_vendor, 
# MAGIC     products.product_description, 
# MAGIC     products.quantity_in_stock, 
# MAGIC     products.buy_price, 
# MAGIC     products.msrp,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'