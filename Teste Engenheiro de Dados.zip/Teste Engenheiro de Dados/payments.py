# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "payments" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)


# COMMAND ----------

target_table_name = "payments"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table payments_update;
# MAGIC create table payments_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   customer_number, 
# MAGIC   check_number, 
# MAGIC   payment_date, 
# MAGIC   amount,	
# MAGIC   'U' flag
# MAGIC from payments

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO payments_update
# MAGIC USING payments
# MAGIC ON payments_update.check_number = payments.check_number AND payments_update.customer_number = payments.customer_number 
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     customer_number = payments.customer_number, 
# MAGIC     check_number = payments.check_number, 
# MAGIC     payment_date = payments.payment_date, 
# MAGIC     amount = payments.amount,
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     customer_number, 
# MAGIC     check_number, 
# MAGIC     payment_date, 
# MAGIC     amount,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     payments.customer_number, 
# MAGIC     payments.check_number, 	
# MAGIC     payments.payment_date, 
# MAGIC     payments.amount,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'