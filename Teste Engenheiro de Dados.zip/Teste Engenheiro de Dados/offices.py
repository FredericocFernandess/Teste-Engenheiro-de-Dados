# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "offices" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)


# COMMAND ----------

target_table_name = "offices"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table offices_update;
# MAGIC create table offices_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   office_code, 
# MAGIC   city, 
# MAGIC   phone, 
# MAGIC   address_line1, 
# MAGIC   address_line2, 
# MAGIC   state, 
# MAGIC   country, 
# MAGIC   postal_code, 
# MAGIC   territory,
# MAGIC   'U' flag
# MAGIC from offices

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO offices_update
# MAGIC USING offices
# MAGIC ON offices_update.office_code = offices.office_code
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     office_code = offices.office_code, 
# MAGIC     city = offices.city, 
# MAGIC     phone = offices.phone, 
# MAGIC     address_line1 = offices.address_line1, 
# MAGIC     address_line2 = offices.address_line2, 
# MAGIC     state = offices.state, 
# MAGIC     country = offices.country, 
# MAGIC     postal_code = offices.postal_code, 
# MAGIC     territory = offices.territory,
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     office_code, 
# MAGIC     city, 
# MAGIC     phone, 
# MAGIC     address_line1, 
# MAGIC     address_line2, 
# MAGIC     state, 
# MAGIC     country, 
# MAGIC     postal_code, 
# MAGIC     territory,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     offices.office_code, 
# MAGIC     offices.city, 
# MAGIC     offices.phone, 
# MAGIC     offices.address_line1, 
# MAGIC     offices.address_line2, 
# MAGIC     offices.state, 
# MAGIC     offices.country, 
# MAGIC     offices.postal_code, 
# MAGIC     offices.territory,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'