# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "customers" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)

# COMMAND ----------

target_table_name = "customers"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table customers_update;
# MAGIC create table customers_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   customer_number, 
# MAGIC   customer_name, 
# MAGIC   contact_last_name, 
# MAGIC   contact_first_name, 
# MAGIC   phone, 
# MAGIC   address_line1, 
# MAGIC   address_line2, 
# MAGIC   city, 
# MAGIC   state, 
# MAGIC   postal_code, 
# MAGIC   country, 
# MAGIC   sales_rep_employee_number, 
# MAGIC   credit_limit,
# MAGIC   'U' flag
# MAGIC from customers

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO customers_update
# MAGIC USING customers
# MAGIC ON customers_update.customer_number = customers.customer_number
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     customer_number = customers.customer_number, 
# MAGIC     customer_name = customers.customer_name, 
# MAGIC     contact_last_name = customers.contact_last_name, 
# MAGIC     contact_first_name = customers.contact_first_name, 
# MAGIC     phone = customers.phone, 
# MAGIC     address_line1 = customers.address_line1, 
# MAGIC     address_line2 = customers.address_line2, 
# MAGIC     city = customers.city, 
# MAGIC     state = customers.state, 
# MAGIC     postal_code = customers.postal_code, 
# MAGIC     country = customers.country, 
# MAGIC     sales_rep_employee_number = customers.sales_rep_employee_number, 
# MAGIC     credit_limit = customers.credit_limit,
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     customer_number, 
# MAGIC     customer_name, 
# MAGIC     contact_last_name, 
# MAGIC     contact_first_name, 
# MAGIC     phone, 
# MAGIC     address_line1, 
# MAGIC     address_line2, 
# MAGIC     city, 
# MAGIC     state, 
# MAGIC     postal_code, 
# MAGIC     country, 
# MAGIC     sales_rep_employee_number, 
# MAGIC     credit_limit,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     customers.customer_number, 
# MAGIC     customers.customer_name, 
# MAGIC     customers.contact_last_name, 
# MAGIC     customers.contact_first_name, 
# MAGIC     customers.phone, 
# MAGIC     customers.address_line1, 
# MAGIC     customers.address_line2, 
# MAGIC     customers.city, 
# MAGIC     customers.state, 
# MAGIC     customers.postal_code, 
# MAGIC     customers.country, 
# MAGIC     customers.sales_rep_employee_number, 
# MAGIC     customers.credit_limit,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'

# COMMAND ----------

# MAGIC %sql
# MAGIC select flag,* from customers_update