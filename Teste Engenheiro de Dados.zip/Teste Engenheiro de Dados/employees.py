# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "employees" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)

# COMMAND ----------

target_table_name = "employees"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table employees_update;
# MAGIC create table employees_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   employee_number, 
# MAGIC   last_name, 
# MAGIC   first_name, 
# MAGIC   extension, 
# MAGIC   email, 
# MAGIC   office_code, 
# MAGIC   reports_to, 
# MAGIC   job_Title,
# MAGIC   'U' flag
# MAGIC from employees

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO employees_update
# MAGIC USING employees
# MAGIC ON employees_update.employee_number = employees.employee_number
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     employee_number = employees.employee_number, 
# MAGIC     last_name = employees.last_name, 
# MAGIC     first_name = employees.first_name, 
# MAGIC     extension = employees.extension, 
# MAGIC     email = employees.email, 
# MAGIC     office_code = employees.office_code, 
# MAGIC     reports_to = employees.reports_to, 
# MAGIC     job_Title = employees.job_Title,
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     employee_number, 
# MAGIC     last_name, 
# MAGIC     first_name, 
# MAGIC     extension, 
# MAGIC     email, 
# MAGIC     office_code, 
# MAGIC     reports_to, 
# MAGIC     job_Title,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     employees.employee_number, 
# MAGIC     employees.last_name, 
# MAGIC     employees.first_name, 
# MAGIC     employees.extension, 
# MAGIC     employees.email, 
# MAGIC     employees.office_code, 
# MAGIC     employees.reports_to, 
# MAGIC     employees.job_Title,
# MAGIC     'I'
# MAGIC   )
# MAGIC WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'