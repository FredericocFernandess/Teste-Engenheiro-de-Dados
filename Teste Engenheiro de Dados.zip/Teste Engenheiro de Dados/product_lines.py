# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "product_lines" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)


# COMMAND ----------

target_table_name = "product_lines"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table product_lines_update;
# MAGIC create table product_lines_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   product_line, 
# MAGIC   text_description, 
# MAGIC   html_description, 
# MAGIC   image,	
# MAGIC   'U' flag
# MAGIC from product_lines

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO product_lines_update
# MAGIC USING product_lines
# MAGIC ON product_lines_update.product_line = product_lines.product_line
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     product_line = product_lines.product_line, 
# MAGIC     text_description = product_lines.text_description, 
# MAGIC     html_description = product_lines.html_description, 
# MAGIC     image = product_lines.image,	
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     product_line, 
# MAGIC     text_description, 
# MAGIC     html_description, 
# MAGIC     image,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     product_lines.product_line, 
# MAGIC     product_lines.text_description, 
# MAGIC     product_lines.html_description, 
# MAGIC     product_lines.image,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'