# Databricks notebook source
driver = "org.postgresql.Driver"

database_host = "psql-mock-database-cloud.postgres.database.azure.com"
database_port = "5432" # update if you use a non-default port
database_name = "ecom1693753481714idinztizgwpbmvet" # eg. postgres
table = "orders" # if your table is in a non-default schema, set as <schema>.<table-name> 
user = "tyzwdkcrstkawzakumosemom@psql-mock-database-cloud"
password = "gkwpffjsosdgowvwmeythlec"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
    .format("jdbc")
    .option("driver", driver)
    .option("url", url)
    .option("dbtable", table)
    .option("user", user)
    .option("password", password)
    .load()
)

# COMMAND ----------

target_table_name = "orders"
remote_table.write.mode("overwrite").saveAsTable(target_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table orders_update;
# MAGIC create table orders_update
# MAGIC using delta
# MAGIC as 
# MAGIC select 
# MAGIC   order_number, 
# MAGIC   order_date, 
# MAGIC   required_date, 
# MAGIC   shipped_date, 
# MAGIC   status, 
# MAGIC   comments, 
# MAGIC   customer_number,
# MAGIC   'U' flag
# MAGIC from orders

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO orders_update
# MAGIC USING orders
# MAGIC ON orders_update.order_number = orders.order_number
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     order_number = orders.order_number, 
# MAGIC     order_date = orders.order_date, 
# MAGIC     required_date = orders.required_date, 
# MAGIC     shipped_date = orders.shipped_date, 
# MAGIC     status = orders.status, 
# MAGIC     comments = orders.comments, 
# MAGIC     customer_number = orders.customer_number,
# MAGIC     flag = 'U'
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     order_number, 
# MAGIC     order_date, 
# MAGIC     required_date, 
# MAGIC     shipped_date, 
# MAGIC     status, 
# MAGIC     comments, 
# MAGIC     customer_number,
# MAGIC     flag
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     orders.order_number, 
# MAGIC     orders.order_date, 
# MAGIC     orders.required_date, 
# MAGIC     orders.shipped_date, 
# MAGIC     orders.status, 
# MAGIC     orders.comments, 
# MAGIC     orders.customer_number,
# MAGIC     'I'
# MAGIC   )
# MAGIC   WHEN NOT MATCHED BY SOURCE THEN --DELETE
# MAGIC   UPDATE SET 
# MAGIC     flag = 'D'